package com.fariantec.djonon.weatherforecast;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.app.Activity;

import org.xmlpull.v1.XmlPullParserFactory;

public class MainActivity extends AppCompatActivity {

    private final static String url = "http://api.openweathermap.org/data/2.5/weather?q=ottawa,ca&APPID=7e943c97096a9784391a981c4d878b22&mode=xml&units=metric";
    private TextView location, country, temperature, humidity, pressure;
    private MainActivity activity;
    private XmlPullParserFactory xmlFactoryObject;
    private ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        location = (TextView) findViewById(R.id.location);
        country = (TextView) findViewById(R.id.country);
        temperature = (TextView) findViewById(R.id.temperature);
        humidity = (TextView) findViewById(R.id.humidity);
        pressure = (TextView) findViewById(R.id.pressure);

        new GetWeatherDataTask (this, url).execute();
    }

    public void callBackData(String[] result) {
        temperature.setText((Float.parseFloat(result[2]) - 273) + " degree Celcius" );
        humidity.setText(result[0] + " %");
        pressure.setText(result[1] + " hPa");
        country.setText(result[4]);
        location.setText(result[3]);
    }
}
